<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='C__Users_asritha_eclipse_java-2022-09_eclipse' timestamp='1679210750567'>
  <properties size='7'>
    <property name='org.eclipse.equinox.p2.cache' value='C:\Users\asritha\.p2\pool'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32'/>
    <property name='org.eclipse.oomph.p2.profile.type' value='Installation'/>
    <property name='org.eclipse.oomph.p2.profile.shared.pool' value='true'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='C:\Users\asritha\eclipse\java-2022-09\eclipse'/>
  </properties>
</profile>
